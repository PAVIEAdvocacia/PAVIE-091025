---
title: "Bem-vindo ao Blog PAVIE"
description: "Primeiro post de exemplo para confirmar o funcionamento do blog."
date: 2025-10-30
tags: ["institucional"]
draft: false
---

Este é um post de exemplo publicado automaticamente na estrutura do blog.  
Assim que o ambiente estiver em produção, você poderá removê-lo e adicionar seus próprios artigos.
