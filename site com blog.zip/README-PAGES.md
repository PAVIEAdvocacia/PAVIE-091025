# Deploy unificado (CommonJS): site raiz + /blog no Cloudflare Pages
Build command: `npm install && npm run build`
Output directory: `pages_out`
