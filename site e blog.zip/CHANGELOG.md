# CHANGELOG — Políticas do Site
## 2025-10-26
- Publicadas as páginas **/privacidade** (Política de Privacidade) e **/termos** (Termos de Serviço).
- Incluídos JSON-LD (`WebPage` e `BreadcrumbList`), metadados OG/Twitter e Consent Mode v2.
- Revisão de microcopy LGPD nos formulários (uso apenas para resposta ao contato).
