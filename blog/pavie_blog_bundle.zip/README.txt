PAVIE | Advocacia — Pacote de integração do Blog em /blog/
Gerado: 2025-10-31 04:20:47

Conteúdo:
- blog_project__astro.config.mjs
- blog_project__src-pages-blog-rss.xml.ts
- site_root__redirects
- snippet__head__feed-rss.html
- snippet__nav-footer__blog-link.html
- copy_blog_dist_to_site.bat

Passos recomendados:
1) No projeto do BLOG (Astro):
   - Coloque "blog_project__astro.config.mjs" como "astro.config.mjs".
   - Garanta que existe a Content Collection "blog" e páginas/postagens OK.
   - Garanta que "src/pages/blog/rss.xml.ts" exista com o arquivo fornecido.
   - Rode: npm ci (ou npm install), depois npm run build.
     O build correto cria: blog/dist/blog/... com index.html, posts etc.

2) Publicação dentro do site raiz (HTML estático):
   - Edite o caminho no "copy_blog_dist_to_site.bat" para seu computador.
   - Execute o .bat para copiar todo o dist/blog para "SITE_ROOT\blog".
   - No site raiz:
       * Adicione no <head> (index e/ou layout base) o snippet "snippet__head__feed-rss.html".
       * Adicione no menu e rodapé o link do arquivo "snippet__nav-footer__blog-link.html".
       * Substitua o arquivo "_redirects" pelo "site_root__redirects" (ou mescle as regras).
   - Faça commit/push para o repositório do site (Cloudflare Pages).
   - Limpe o cache na Cloudflare (se necessário).

3) Teste após publicar:
   - Acesse https://pavieadvocacia.com.br/blog/
   - Acesse https://pavieadvocacia.com.br/blog/rss.xml
   - Valide que imagens, CSS e links das postagens carregam (base '/blog/' correta).

Observações:
- O arquivo _redirects fornecido apenas canonicaliza WWW -> apex. Ele não interfere no /blog/.
- Se você já possui um _redirects com outras regras, mescle mantendo as linhas WWW -> apex.
- O bundle não altera formulários nem scripts do site principal; apenas adiciona links.
